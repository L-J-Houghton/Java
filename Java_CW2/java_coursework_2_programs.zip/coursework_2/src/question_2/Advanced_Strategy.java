package question_2; // package name.
import java.io.*; // java import/output package.
import java.awt.*; // importing awt package.
import java.awt.event.*;// importing awt event package (used for action/listener events).
import javax.swing.*; // importing swing package.
import java.util.Random; // importing Random package.
import java.util.ArrayList; // importing array list package.
import java.util.Arrays; // importing arrays package.

public class Advanced_Strategy extends JFrame implements ActionListener{ // Advanced strategy class inherits JFrame class and implements ActionListener.

	input com_guess[][]; // input used to take in the input/guess from the computer or player.
    output bwPegs[][]; // bwPegs used to output the number of black and white pegs.
    
    input kb[]; // used to store and display the input (data) from the guess.
    JButton Enter; // used to enable the machine to enter a guess.
    
    int count; // used to keep track of number of guesses the machine has made.
    int type; // used to store what type of game mode the machine is playing , player or machine guess.
	
    String kbValue = new String(); // used to represent the key value / combination as a string.
    
    Random ran = new Random(); // random object used to generate random combination.
    
    public static void main(String args[]) { // main method.
        new Advanced_Strategy(); // initialising new advanced strategy game.
    }
    
    public Advanced_Strategy() { // constructor for advanced strategy.
        super("Advanced Strategy - Luke Houghton");// super class Advanced_Strategy.
        initGUI(); // calling and initialising/creating the gui.
        initVals(); // calling function initialiseVals to initialise values.
        Listeners(); // calling the event listeners function.
    }// end constructor.
    
    public void initGUI(){ // function used to setup the gui itself with aesthetical features/components of mastermind boardgame.
        JPanel main = new JPanel(); // creating the main panel using JPanel.
        main.setBackground(new Color(165,82,0)); // setting the background colour of the main panel to a brown colour.
        main.setLayout(new GridLayout(11, 2, 0, 15)); // setting the layout of the main panel using Gridlayout.
        JPanel key = new JPanel(); // creating a new panel key to store hidden combination.
        key.setBackground(new Color(165,82,0)); // setting the background ok key to the same colour as the main panel.
        key.setLayout(new FlowLayout()); // new flow layout used to keep it centre aligned.

        // creating buttons to store kb , and adding to the key panel
        kb = new input[4]; // allow computer to have an input of 4 buttons on each guess.
        for (int i=0; i<4; i++) { // loop through hidden combination
            kb[i] = new input(); // add a new button until i hits the combination limit , in this case 4 pegs.
            key.add(kb[i]);// add the input buttons to the key panel.
        }

        // break between key and guesses
        main.add(new JSeparator(SwingConstants.HORIZONTAL)); // adding a separator in between the kb and the guess elements within gui.
        main.add(new JSeparator(SwingConstants.HORIZONTAL));// adding a separator in between the kb and the guess elements within gui.

        //create guess panels and corresponding clue panels
        JPanel guessPan[] = new JPanel[10];// creating the guess panel with a value of 10 to allow computer to guess upto 10 times. 
        JPanel bwPan[] = new JPanel[10]; // creating 10 panel allowing 10 sets of black and white pegs within gui.
        com_guess = new input[10][4]; // allowing computer to guess 4 combinations in length and total of 10 guesses.
        bwPegs = new output[10][4]; // creating the black and white pegs for total number of guesses (10) and 4 pegs for each guess.
        for (int i=0; i<10; i++) { // for every guess (10 guesses) do the following.
            bwPan[i] = new JPanel(); // create a panel to store the black and white pegs.
            bwPan[i].setBackground(new Color(165,82,0)); // set the background the of the panel to brown.
            bwPan[i].setLayout(new GridLayout(1,4));// set grid layout to 1 by 4 (in a row). 
            guessPan[i] = new JPanel(); // create another panel for black and white pegs.
            guessPan[i].setBackground(new Color(127,64,1));// setting background of computer guess panel to a dark brown colour.
            for (int j=0; j<4; j++){ // for every button/peg guess do the following.
                bwPegs[i][j] = new output(); // display new black/white pegs.
                bwPan[i].add(bwPegs[i][j]); // add new black and white pegs to the panel.
                com_guess[i][j] = new input(); // display and give the computer the guessing (peg) buttons.
                guessPan[i].add(com_guess[i][j]); // add the guessing buttons to the computer's guess panel.
            }
            main.add(bwPan[i]); // add  the black and white pegs to the panel.
            main.add(guessPan[i]); // add black and white pegs to the panel.
        }

        // enter button
        Enter = new JButton("Enter combination"); // button used to also allow the player to play if wanted.
        JPanel enter = new JPanel(); // creating panel for enter button.
        enter.setBackground(new Color(0,169,230)); // setting background colour of enter button.
        enter.add(Enter); // adding enter button to the enter panel.

        // main container pane.
        Container win = this.getContentPane(); // initialising new container to store panels.
        win.setLayout(new BorderLayout()); // initialising new layout.
        win.add(key, BorderLayout.NORTH); // add the key panel to the north of container
        win.add(main, BorderLayout.CENTER);// add the main panel to centre of panel.
        win.add(enter, BorderLayout.SOUTH);// add the enter panel to the south of the container pane.

        this.setDefaultCloseOperation(Advanced_Strategy.EXIT_ON_CLOSE); // exit on window close.
        this.setSize(400, 700); // set size of the window
        this.setVisible(true);// make visible to user.
    }

    public void initVals() {// initialise values (on start / restart).
        //ask for and set game mode
        Object[] option = {"Player", "Machine"}; // give user option of either playing or machine playing.
        type = JOptionPane.showOptionDialog(null,"Select a playing option","Select a Game Mode", // prompt.
                                            JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null, // yes and no options.
                                            option,option[0]);// option buttons
        count = 9;// put the guess count to 9.
        for (int i=0;i<4;i++) { // for every 4 choices / pegs do following
            if (type == 0) { // if the user selects yes from above , then enter player option.
                kb[i].setViz(false); // set the guess code to false.
                kb[i].setColour((ran.nextInt(6) + 1)); // randomise the colour combination for user to guess.
            } else { // set to machine play.
                kb[i].setColour(0);// current colour 
                kb[i].setEdit(true);// allow the user to select own combination for machine to guess.
            }
        }
        if (type == 0) {// if the user selects player mode then do the following.
            kbValue = stringVal(kb); // take the value of the random combination and assign it to the hidden combination if in player option.
        }// end if.
        for (int i=0; i<10; i++) {
            for (int j=0; j<4; j++) {
                com_guess[i][j].setColour(0); // set current colour/ peg combination made by the computer
                if (i==9 && type == 0) { // if number of guesses is 9 (10 in total) then do the following
                    com_guess[i][j].setEdit(true); // show combination (see input class).
                } else {//else
                    com_guess[i][j].setEdit(false); // do not allow user to see combination (see input class).
                }// end else.
                bwPegs[i][j].setColour(0); // set the black/white pegs to default colour (see output class).
            }// end for
        }// end for
    }// method
    // get string value of a set of input buttons
    // this is helpful to have for scoring
    public String stringVal(input[] buttons) { // storing the value of the coloured peg buttons as a string , to allow user to loop through coloured peg selection.
        String val = new String(); // initialising new string object val to store value of colours as a string.

        for (int i=0; i<buttons.length; i++) {// 
            val += String.format("%d", buttons[i].getColour());// get the current colour what the user/machine is on and assign it to val as a string.
        }// end for

        System.out.println(val); // print out current value of button to console for testing purposes.
        return val;// return the string val.
    }

    // register listener for enter button
    public void Listeners() {// listeners function to handle event listener.
        Enter.addActionListener(this); // add an action listener to the enter button.
    }

    // setting action for enter button
    public void actionPerformed(ActionEvent e) {// function to handle the actions performed within window.
        System.out.println(e.getActionCommand()); // print out the command made by user/machine to console for testing purposes.
        if (e.getSource() == Enter && type == 0) { // if the user has pressed enter and the type (game type) is 0 do the following
            // player mode
            submit();// call submit function to allow user to submit guess.
        } else if (e.getSource() == Enter && type == 1) { // else if enter has been pressed and  the user selects 2nd (option[1]) then do the following
            // machine mode
            playMachine(); // call the playMachine function , enabling machine to guess.
        } else {// else
            System.out.println("ACTION EVENT ERROR!"); // print out error if the above fails.
        }
    }
    
    public void submit() {// checks to see if the guess made by player or machine is correct.
        boolean success = false; // set boolean of success to false , initially.
        if (valid(com_guess[count])) { // check to see if the input/guess is valid.
            success = returnBW(); // set the boolean success to return a black or white peg(s) (see output.class).
            if (success) {// if sucess is true
                System.out.println("Sucess"); // print out success in console for testing purposes.
                fail(true);// set fail to true intially.
                return;// return false.
            }

            
            count--; // decrement guess counter for the next guess

            // check if out of guesses, player loses
            if (count < 0) { // if the user/machine has more than 10 guesses then do the following
                fail(false); // set fail to false.
                return; // return.
            }

            
            for (int i=0; i<4; i++) { // loop through the current peg combination.
                com_guess[count][i].setEdit(true); // enable next guess.
                com_guess[count+1][i].setEdit(false); // diable previous guess.
            }
        }
    }
    
    public boolean valid(input[] button) { // valid functiond used to check to see if the input by user/machine is valid.
        for (int i=0; i<4; i++) { // 
            if (button[i].getColour() == 0) {// get the current colour that the user / machine is on , if it's value is 0 
                return false; // then return false.
            }
        }
        return true; // return true if the input/guess is valid.
    }
    public void fail(boolean win) { // fail function used to check if the player / machine has exceeded guesses , basically lost.
        // reveal the key
        for (int i=0; i<4; i++) { // loop through the 4 peg hidden combination.
            kb[i].setViz(true); // set the hidden combination visibility to true , enabling user to see it.
        }
    
    String prompt = new String(); // 
    if (win) {// if win is true do following
        prompt = "Game won!"; // prompt user game is won.
    } else {// else.
        prompt = "Game lost!"; // prompt user , game is lost.
    }

    // display message and ask for new game
    int ans =
        JOptionPane.showConfirmDialog(null,"Do you want to play again?",prompt, JOptionPane.YES_NO_OPTION, // show prompt in dialog box with yes/no options.
                                      JOptionPane.PLAIN_MESSAGE);// plain pane message format.

    // reset game, or end
    if (ans == 0) {// if option is yes then do the following
        initVals(); // re-initialise the values of the game , reset the game over again.
    } else if (ans == 1) {//else if the option is no do the following.
        System.exit(0); // exit/close window.
    } else {// else
        System.out.println("ERROR!"); // print error message to console for testing purposes.
    }
}
    public void playMachine() { // machine plays function
        // make sure user has entered a valid key
        if (valid(kb)) {
            // holds computer guess and score of guess
            String initial_guess = new String(); // holds machine initial guess
            String[] sc = new String[2]; // holds score of the guesses.

            
            ArrayList<String> possible = new ArrayList<String>(); // holds all possible combinations (1296).

            ArrayList<String> keep = new ArrayList<String>();// hold keys that have not been ruled out.

            // seeds arraylists - to start both hold all 1296 possible combinations.
            // keys. possible values are 1111-6666, using 1-6 only as there are only 6 colours to choose from.
            for (int i=1111; i<6667; i++) { // loop through all possible values.
                if ( !String.format("%d", i).contains("0") && // if the combination contains a 0 , do not add
                     !String.format("%d", i).contains("7") && // if the combination contains a 7 , do not add
                     !String.format("%d", i).contains("8") && // if the combination contains a 8 , do not add
                     !String.format("%d", i).contains("9") ) { // if the combination contains a 9 , do not add
                	// else add all values of i.
                    possible.add(String.format("%d", i)); // add all values of i to the possible combination arraylist.
                    keep.add(String.format("%d", i)); // add all values of i to the keep arraylist.
                }
            }

            
            kbValue = stringVal(kb);// save string version of user provided combination.

            // computer's initial guess
            // display guess, check for a win and display clue
            // calculate guess score
            initial_guess = "1122"; // computer's initial guess as suggested in Knuth's algorithm , see advanced strategy pdf
            com_guess[count][0].setColour(1); // set the first button colour to 1 , red.
            com_guess[count][1].setColour(1); // set the second button colour to 1 , red.
            com_guess[count][2].setColour(2); // set the third button colour to 2 , blue.
            com_guess[count][3].setColour(2); // set the fourth button colour to 2 , blue.
            submit();
            sc = score(kbValue, initial_guess).split(","); // store the score of the initial guess as a string for further use.

            // try until out of guesses or we win
            while (count >= 0 && !sc[0].equals("4")) { // while the count is larger than 0 and the score does not equal a total of 4 correct combination do following.
                // rule out impossible guesses from the remaining guesses
                for (int i=0; i<keep.size(); i++) { // lopp through the keep arraylist made.
                    // score our guess versus a possible combination
                    // if the score does not match the actual score, then this must not be a possible combination
                    while (i != keep.size() && !Arrays.deepEquals(sc,score(keep.get(i),initial_guess).split(","))) {
                        keep.remove(i);// remove the value of i , leaving only the values/combinations with the highest probability.
                    }
                }

                // if there is only one possibility left it must be the correct combination. computer enters guess..
                if (keep.size() == 1) { // if the size of the keep arraylist is 1 do the following.
                    initial_guess = keep.get(0); // get the remaining combination.
                } else {// else do the following.
                    // otherwise we must calculate the best possible
                    // guess: The guess that minimizes the maximum number of remaining possibilities
                    int minval = 1296; // set the minimum value to 1296 potential combinations
                    for (int i=0; i<possible.size(); i++) {// loop through the possible arraylist and do the following.
                        // for any possible guess calculate the max number of possibilities left after that guess
                        int tmp = getMax(possible.get(i), keep);// get the maximum value from possible arraylist and compare with the keep arraylist , what ever value is highest assign to the temporary variable.
                        if (tmp < minval) { // if the temporary value is lower than the minimum value (1296) do the following.
                            minval = tmp;// set the minimum value to the temporary value .
                            initial_guess = possible.get(i);// assign the value combination (i) found within the possible arraylist.
                        }
                    }
                }

                // the combination with highest probability has been found 
                for (int i=0; i<4; i++) { // loop to loop through each guess peg.
                    com_guess[count][i].setColour(Integer.parseInt(initial_guess.substring(i, i+1))); // set the colour / values of the combination of the computer guess.
                }
                sc = score(kbValue, initial_guess).split(",");// use line split to ignore ',' in arraylist and assign the score of the combination(s).
                submit(); // submit the guess made by the machine/computer.
            }
        }
    }
    public int getMax(String attempt, ArrayList<String> set) { // used for getting the combination with maximum score (probability).
        
        String[] scores = {"0,0", "0,1", "0,2", "0,3", "0,4", "1,0", "1,1", // possible scores of black/white pegs.
                           "1,2", "1,3", "2,0", "2,1", "2,2", "3,0", "4,0"}; // possible scores of black/white pegs.
        // counter
        int max = 0; // assign max combination int to zero.

        
        for (int i=0; i<scores.length; i++) { // for each possible score , do following
            int maxCount = 0; // assign count variable to zero , initially.
            
            
            for (int j=0; j<set.size(); j++) { // for loop to compare guess to remaining possible combinations
                if (score(set.get(j), attempt).equals(scores[i])) { // compare guess to remaining possible combinations
                    maxCount++; // keeping track of the maximum eliminated by a potential score
                }
            }
            
            if (maxCount > max) { // if the maxCount value is larger than max (0) then do following.
                max = maxCount; // assign the maxCount value to the max value.
            }
        }
        // and finally return the accurate max value / combination.
        return max; // return the maximum value / combination.
    }
    // show the clue for the current guess
    public boolean returnBW() { // return black / white values.
        
        int exMatch = 0; // exMacth created to store the number of exact matches (blacks).

        
        int colrMatch = 0; // colrMatch created to store the number of exact matches (whites).

        
        int res = 0; // current peg.

        // string representation of guess
        String com_guessValue = new String(); // string object to store the values of the machine guess as a string (for further use).

        
        String sc[] = new String[2]; // storing the score as a string 

        
        com_guessValue = stringVal(com_guess[count]);// get string of guess, then giving it a score
        sc = score(kbValue, com_guessValue).split(",");// taking the hidden value and computer guess value to get white/black peg score.
        System.out.println(sc[0] + "," + sc[1]); // printing out white / black peg scores to console for testing purposes.

        
        for (int i=Integer.parseInt(sc[0]); i>0; i--) { // loop through the black peg score variable whilst the value is greater than 0
            bwPegs[count][res].setColour(2); // colour the black pegs if matched correctly.
            res++;// increment the result
        }
        for (int i=Integer.parseInt(sc[1]); i>0; i--) { // loop through white the score variable whilst the value is greater than 0
            bwPegs[count][res].setColour(1); // colour the white pegs if matched correctly.
            res++; // increment the result
        }

        // tell the user if they've won or not
        if (sc[0].equals("4")) { // if the score equals 4 , do the following.
            return true; // return true / win.
        } else {// else 
            return false;  // return false.
        }
    }
    public String score(String key, String guess) { // score used for and to calculate the score of the probability combinations.
        int bMatch = 0; // black matches.
        int wMatch = 0;// white matches.

        
        for (int i=0; i<4; i++) { // loop through the 4 element combination.
            if (key.charAt(i) == guess.charAt(i)) { //find the exact matches
                bMatch++; // increment black match, found.
            }//end if
        }// end for

        
        for (int i=1; i<7; i++) {// loop through until 
        	// calculating white matches by finding the minimum between the white count of the key (combination) and the guess(combination) 
            wMatch += Math.min(count(key, Character.forDigit(i,10)),count(guess, Character.forDigit(i,10))); // increment white matches on every cycle (see line above).
        }// end for.

        
        wMatch -= bMatch; // since these can overlap , remove the black matches from the white matches.

        
        return bMatch + "," + wMatch; // return number of black and white pegs.
    }

    public int count(String val, char x) { // counts the number of a given colour in a guess/combination and is used for scoring
        int count = 0; //  assign count zero , initially
        for (int i=0; i<val.length(); i++) {// loop through the value (parsed as an argument) given 
            if (val.charAt(i) == x) { // if the value/combination given has a correct colour and/or position do the following
                count++; // increment the count value.
            }
        }
        return count; // return count value.
    }
}
    
/*REFERENCES:

Java Labs
Java Lectures
I had used an online reference as a guide to learn about the arrays.deepEquals method - https://docs.oracle.com/javase/7/docs/api/java/util/Arrays.html
I had used an online reference as a guide to learn about the Math.min method - https://docs.oracle.com/javase/7/docs/api/java/lang/Math.html
I had used an online reference as a guide to refer to swing components - https://docs.oracle.com/javase/7/docs/api/javax/swing/package-summary.html

Please refer to pdf provided Advanced_Strategy.pdf which explains my research of the strategy used.

*/