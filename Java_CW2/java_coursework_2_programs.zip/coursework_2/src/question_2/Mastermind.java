package question_2;// package name

import java.awt.BorderLayout; // importing boarder layout package.
import java.awt.Color; // importing colour package.
import java.awt.GridLayout;// importing grid layout package.
import java.awt.FlowLayout;// importing flow layout package.
import java.awt.event.ActionEvent;// importing action event package.
import java.awt.Dimension;// importing dimension package.
import java.awt.event.ActionListener;// importing action listener package.
import java.io.InputStream;// importing input stream package (not used).
import java.util.Random;// importing random package.
import java.util.Scanner;// importing scanner package (not used).
import javax.swing.BorderFactory;// importing boarder factory package.
import javax.swing.JButton;// importing JButton package.
import javax.swing.JFrame;// importing JFrame package.
import javax.swing.JLabel;// importing JLabel package.
import javax.swing.JOptionPane;// importing JOptionPane package.
import javax.swing.JPanel;// importing JPanel package.
import java.util.Random;// importing boarder layout package (duplicate).

public class Mastermind extends JFrame  implements ActionListener { // Creating public class mastermind that extends the JFrame class (import) and implements ActionListener interface.
       
	int width; //  creating integer width for gui purposes.
	int height; // creating height for gui purposes.
	int numColors; // creating varibale 'numColors' that will store the number of potential colours of the pegs within the game.
	int numGuesses; // creating variable to store number of guesses of player/machine.
	JButton[][] colouredPegs;// two dimensional array to store the indices of the coloured pegs as buttons.
	JButton[][] whites;// two dimensional array to store the indices of the white pegs as buttons. 
	JButton[][] blacks;// two dimensional array to store the indices of the black pegs as buttons.
	JButton[] computerGuess; // Array to store the guesses / index of guesses made by the machine.
	int state[][]; // creating the two dimensional array which shall hold the current state (combination) of the user's selection before entering. 
	int[] hiddenGuess; // storing the hidden guesses within an array 'hiddenGuess'.
	JButton guess = new JButton("Guess"); // creating button with the content Guess , allowing user to enter their guess.
	JPanel colouredPanel = new JPanel(); // creating a new panel that shall hold the coloured pegs selected by the user.
	JPanel whitesPanel = new JPanel(); // creating a new panel which will be able to store the white pegs made above.
	JPanel blacksPanel = new JPanel();// creating a new panel which will be able to store the black pegs made above.
	JPanel computerGuessPanel = new JPanel(); // creating a new panel which will be able to store the guesses made by the computer.
    JPanel panel2 = new JPanel(); // creating a new panel.
	Random rand; // creating a random object 'rand' used to randomly assign values as a computer generated combination.
	static int blacks (int [] one, int [ ] two)// blacks integer method used to decide whether user has correctly guesses colour and position.
	{
		int val=0; // set the value of black pegs to zero.
		for (int i=0;i<one.length;i++) // loop through the first array parsed.
		{
		  if (one[i]==two[i]) val++; // if the index value(s) of the first array parsed are equal to that of the second array parsed then increment number of black pegs. 
		
		}
	        return val;// return value of black pegs.
	}
	
	static int whites (int [] one, int [ ] two)// whites integer method used to decide whether user has correctly guesses colour and position.
	{
		boolean found; // boolean found used to see if value is found (true) else if not found (false).
		int [ ] oneA = new int[one.length];  // storing the size of the first array parsed into another array oneA.
		int [ ] twoA = new int[one.length]; // storing the size of the first array parsed into another array twoA.
		for (int i=0;i<one.length;i++) // looping through indices of both arrays parsed into method.
		{
			oneA[i]=one[i]; twoA[i]=two[i]; // assigning each index of the arrays parsed to the method arrays made above.
		}
		int val=0; // setting value of white pegs to zero.
		for (int i=0;i<one.length;i++)// until i reaches the length of the first array parsed do the following.
		if (oneA[i]==twoA[i]) {oneA[i]=0-i-10;twoA[i]=0-i-20;} // if incremented index i (in oneA array) is equal to that of the incremental index i of the twoA array 
		
		for (int i=0;i<one.length;i++) // loop through all indices of the first array parsed.
		{ found=false; // set found to false if no matches.
		  for (int j=0;j<one.length && !found;j++) // nested for loop used to loop through the arrays above if an index (colour) matches and has been found.
		  { 
		   if (i!=j && oneA[i]==twoA[j]) // if the index i in the first array is not equal to index j in second array , so if the user's selected peg is not equal to the computer selected peg but the colours are the same do following.
		   {val++;oneA[i]=0-i-10;twoA[j]=0-j-20;found=true;} // set found to true and increment the number of white pegs.
		  }// end for
		
	        }//end for
		return val; // return the value of white pegs.
	}
	static Color choose(int i)// making a static method that shall return the colour chosen by user or computer.
		{
		  if (i==0) return Color.red; // if the variable i happens to have an index of 0 , then the colour chosen shall return red.
		  if (i==1) return Color.green; // if the variable i happens to have an index of 1 , then the colour chosen shall return green.			
		  if (i==2) return Color.blue;// if the variable i happens to have an index of 2 , then the colour chosen shall return blue.
		  if (i==3) return Color.orange;// if the variable i happens to have an index of 3 , then the colour chosen shall return orange.
		  else return Color.yellow;// else if the variable i happens to be neither then by default return yellow , then the colour chosen shall return yellow.
		  
		}
		
	public Mastermind(int h, int w, int c) { // Mastermind constructor with method variables h = height of button(s) ,w = width of button(s) and c = number of colours used (pegs).
		width=w;height=h; numColors=c; // assigning method variables to variables used within this constructor.
		numGuesses=0; // stores number of guesses made by the user or computer.
		hiddenGuess = new int[width]; // assigning a new integer to the hidden guess array with the value of the width variable assigned.
		rand=new Random();// assigning random integer to the random object made above using random object.
		state = new int[height][width]; // assigning new integers to the state (current user combination) using the variables height and width assigned.
		colouredPegs= new JButton[height][width];// creating buttons using JButtons that will be used as for the coloured pegs / buttons. Assigning the sizing of the buttons to width and height varibales.
		whites= new JButton[height][width]; // creating new buttons that will store the height and width of the white pegs.
		blacks= new JButton[height][width]; // creating new buttons that will store the height and width of the black pegs.
		computerGuess= new JButton[width]; // creating a computer guess button with the use of a JButton whose width will be assigned using the width variable.
		colouredPanel.setLayout(new GridLayout(height,width)); // using swing's Gridlayout to set the layout of the coloured (pegs) panel using the variables height and width to set size. 
		blacksPanel.setLayout(new GridLayout(height,width)); // using swing's Gridlayout to set the layout of the black (pegs) panel using the variables height and width to set size.
		whitesPanel.setLayout(new GridLayout(height,width)); // using swing's Gridlayout to set the layout of the white (pegs) panel using the variables height and width to set size.
		computerGuessPanel.setLayout(new GridLayout(1,width));// using swing's Gridlayout to set the layout of the computer guesses panel using 1 as the height and width to set size.
		colouredPanel.setBorder(BorderFactory.createEmptyBorder(20, 20,20, 20));// using border factory (imported from swing) to create an empty border with set values around the coloured pegs panel.
		whitesPanel.setBorder(BorderFactory.createEmptyBorder(20, 20,20, 20));// using border factory (imported from swing) to create an empty border with set values around the white pegs panel.
		blacksPanel.setBorder(BorderFactory.createEmptyBorder(20, 20,20, 20));// using border factory (imported from swing) to create an empty border with set values around the black pegs panel.
		
		
		class bing implements ActionListener // class bing implements the Actionlistener interface within the swing import , this tracks the users actions within the program.
		{   
			int x; int y;
		   	
			public void actionPerformed(ActionEvent e) { // action performed method parses actionEvent variable (e).
			  state[x][y]=(state[x][y]+1)%numColors;// allow the current state (current peg colour) to be changed on every click.
			  System.out.println(x + " " +y); // print out the what indices within the two dimensional array / matrix associated with state (two dimensional array that stores the current state of colours) when user clicks on indices.
			 
((JButton)(e.getSource())).setBackground(choose(state[x][y]));// once the button is pressed get the e (action listener) which triggers 
			}
		       
		       public bing (int p,int q) // bing constructor , see above class.
		       {
		         x=p;y=q; // assign int variable x to p and int variable y to q.
		       
		       }
		
		}
		
		for (int k = 0; k < width; k++) // for loop used to display the computer's peg combination (random code choice) within the gui. 
		{
		  computerGuess[k]= new JButton(); // create a new computer guess button using JButton until int k reaches the width set within mastermind constructor.
		  computerGuess[k].setVisible(false); // set visible to false , so that each computer guess button will not be visible to the user.
		  computerGuessPanel.add(computerGuess[k]);// adding the computer's randomly selected peg combination to the panel.
		  hiddenGuess[k]=rand.nextInt(numColors);// selecting random integers from 0 to the value of numColours and setting that value to the specified index of k.
		  computerGuess[k].setBackground(choose(hiddenGuess[k])); // setting the colour background of the value assigned to index k , example if k = 0 , then set background to red.
		}
		
		for (int i = 0; i < height; i++)  // for loop used to increment variable i (see below) until i reaches the height variable set in constructor. 
		for (int j = 0; j < width; j++) // nested for loop used to increment variable j (see below) until j reaches the width variable set in constructor.
		 {
		   System.out.println(i +" "+j); // print the values of i and j every time the for loops are run.
		   state[i][j]=0; // resetting the state indices from the previous i and j values to 0.
		   colouredPegs [i][j]= new JButton(); // create a new button using JButton with the current index values of i and j , assigned within the for loops above.
		   colouredPegs [i][j].addActionListener(new bing(i,j)); // add a new action listener (bing , see above bing class) 
		   colouredPegs [i][j].setBackground(choose(state[i][j]));// set the background colours of each
		   
		   
		  
		   whites [i][j]= new JButton(); // create a new JButton object for each of the white pegs ranging from the height variable to the width variable , create them at height position = i and width position = j.
		   whites [i][j].setVisible(false);// set visible to false to make it invisible within the gui / to the user.
		   whites [i][j].setBackground(Color.white);// set background colour of each white peg within the whites two dimensional array (matrix) to white.
		   blacks [i][j]= new JButton();// create a new JButton object for each of the black pegs ranging from the height variable to the width variable , create them at height position = i and width position = j.
		   blacks [i][j].setVisible(false);// set visible to false to make it invisible within the gui / to the user.
		   blacks [i][j].setBackground(Color.black);// set background colour of each black peg within the blacks two dimensional array (matrix) to black.
		   
		   colouredPanel.add(colouredPegs [i][j]); // add each coloured peg with the index values of i (height) and j (width) to the coloured panel.
		   whitesPanel.add(whites [i][j]); // add each white peg with the index values of i (height) and j (width) to the whites panel.
		   blacksPanel.add(blacks [i][j]); // add each black peg with the index values of i (height) and j (width) to the blacks panel.
		   if (i>0) // if i (height) reaches above zero.
		   colouredPegs[i][j].setVisible(false);// set the coloured pegs thereafter to be invisible to the user.
		 }
		
		setLayout(new BorderLayout()); // setting the layout by creating a new border layout (see swing import).
		add(blacksPanel, "West"); // adding the blacks panel to the left (west side) of the layout.
		add(colouredPanel, "Center"); // adding the blacks panel to the middle (center) of the layout.
		add(whitesPanel, "East"); // adding the blacks panel to the right (east side) of the layout.
		JPanel guessPanel = new JPanel(); // creating new panel using JPanel which will display the guesses.
		guessPanel.setLayout(new FlowLayout()); // arranges the components of guess panel within a line / flow.
		guessPanel.add(guess);// adding the user guess panel.
		add(guessPanel,"South"); // adding the guess panel to the bottom (south) of the layout.
		JPanel topPanel = new JPanel(); // creating a new panel using JPanel for the top panel which shall contain 
		topPanel.setBorder(BorderFactory.createEmptyBorder(20, 20,20, 20));
		topPanel.setLayout(new GridLayout(1,3));// setting a new layout using gridlayout class consisting of 1 row and 3 columns.
		topPanel.add(new JLabel("Blacks",JLabel.CENTER));// creating a label entitled "Blacks" which will be used as a title to the whites panel.
		topPanel.add(computerGuessPanel);// adding the guess panel which shall hold the combination made by the computer.
		topPanel.add(new JLabel("Whites",JLabel.CENTER));// creating a label entitled "Whites" which will be used as a title to the whites panel.
		add(topPanel,"North"); // adding the top panel to the top (north) of the layout.
		setDefaultCloseOperation(3);// declaring default close operation with option int 3.
		setTitle("Mastermind"); // setting title of the panel.
		setMinimumSize(new Dimension(width*50,height*50)); // setting the minimum size of the panel with the dimensions of the variables width and height multiplied by 50.
		pack(); // pack method used to size the frame so that all its contents are at or above their preferred sizes.
		setVisible(true); // making the above visible.
		guess.addActionListener(this); // adding the action listener made to the guess panel to enable interaction.
	}

	public void actionPerformed(ActionEvent e) { // action performed method parses actionEvent variable (e).
		int whiteThings=whites(state[numGuesses],hiddenGuess);// the number of white pegs are assigned to the integer value returned by the static function whites , which parses through index of the array 'state' with the index being the number of current guesses also parses through hidden guesses array. 
		int blackThings=blacks(state[numGuesses],hiddenGuess);// the number of black pegs are assigned to the integer value returned by the static function blacks , which parses through index of the array 'state' with the index being the number of current guesses also parses through hidden guesses array.
		for (int i=0;i<width;i++)colouredPegs[numGuesses][i].setEnabled(false);// until i reaches the width of the panel, enable user to change colour of the pegs of the previous guess.
		if (blackThings==width) // if the variable blackthings is equal to that of the variable width do the following.
		{  for (int i=0;i<blackThings;i++)blacks[numGuesses][i].setVisible(true);// for every time i until i reaches the total number of blackthings , display the each black the user has got.
		for (int i=0;i<width;i++) computerGuess[i].setVisible(true);// for every time i is less than the width of panel , do not display the computer's selection of pegs.
			int n = JOptionPane.showConfirmDialog(this,"You've Won! Would you like to play again?", "",JOptionPane.YES_NO_OPTION); // storing the dialogue box with prompt and yes/no option to variable n. 
			if (n == JOptionPane.NO_OPTION) System.exit(0); // if the user selects no from the dialogue box then the program shall quit / exit.
			else { dispose();new Mastermind(height,width,numColors);} // else if user selects yes the program will dispose of any data in the current frame and reset values. A new game is then created thereafter.
		         }// end if
		if (numGuesses< height) // if the number of guesses made by the user is less than the height of the panel then do the following.
		{
		  for (int i=0;i<whiteThings;i++) whites[numGuesses][i].setVisible(true); // for every time i is less than whitethings display the number of white pegs the user has guessed correctly.
		  for (int i=0;i<blackThings;i++)blacks[numGuesses][i].setVisible(true);// for every time i is less than blackthings display the number of black pegs the user has guessed correctly.
		  			numGuesses++; // increment the number of correct guesses every time for loop is run.
		  if (numGuesses< height) // if the number of guesses is less than height of panel do following.
			  for (int i=0;i<width;i++) colouredPegs[numGuesses][i].setVisible(true);// 
		  else { // else do
			  for (int i=0;i<width;i++) computerGuess[i].setVisible(true); // display the computers selected combination if the number of guesses exceeds the height of panel.
			int n = JOptionPane.showConfirmDialog(this,"You've lost! Would you like to play again?", "You've Won!",JOptionPane.YES_NO_OPTION);// storing the dialogue box with prompt and yes/no option to variable n. 
			if (n == JOptionPane.NO_OPTION) System.exit(0);// if the user selects no from the dialogue box then the program shall quit / exit.
			else { dispose();new Mastermind(height,width,numColors);} // else if user selects yes the program will dispose of any data in the current frame and reset values. A new game is then created thereafter.
		         }//end else.
	        }// end if.		
	}// end method.
	
	
	public static void main(String[] args) { // main function.
		new Mastermind(10,4,5); // initialise new game using the Mastermind class made above with set variables for height , width and number of colours.
	}// end main function.

	
}// end class.
