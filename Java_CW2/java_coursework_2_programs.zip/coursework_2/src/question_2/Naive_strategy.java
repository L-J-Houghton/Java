package question_2; // package name.
import java.io.*; // java import/output package.
import java.awt.*; // importing awt package.
import java.awt.event.*;// importing awt event package (used for action/listener events).
import javax.swing.*; // importing swing package.
import java.util.Random; // importing Random package.
import java.util.ArrayList; // importing array list package.
import java.util.Arrays; // importing arrays package.

public class Naive_strategy extends JFrame implements ActionListener{ // Advanced strategy class inherits JFrame class and implements ActionListener.

	input com_guess[][]; // input used to take in the input/guess from the computer or player.
    output bwPegs[][]; // bwPegs used to output the number of black and white pegs.
    
    input kb[]; // used to store and display the input (data) from the guess.
    JButton Enter; // used to enable the machine to enter a guess.
    int moves = 1;
    int count; // used to keep track of number of guesses the machine has made.
    int type; // used to store what type of game mode the machine is playing , player or machine guess.
	
    String kbValue = new String(); // used to represent the key value / combination as a string.
    
    Random ran = new Random(); // random object used to generate random combination.
    
    public static void main(String args[]) { // main method.
        new Naive_strategy(); // initialising new advanced strategy game.
    }
    
    public Naive_strategy() { // constructor for advanced strategy.
        super("Naive Strategy - Luke Houghton");// super class Advanced_Strategy.
        initGUI(); // calling and initialising/creating the gui.
        initVals(); // calling function initialiseVals to initialise values.
        Listeners(); // calling the event listeners function.
    }// end constructor.
    
    public void initGUI(){ // function used to setup the gui itself with aesthetical features of mastermind boardgame.
        JPanel main = new JPanel(); // creating the main panel using JPanel.
        main.setBackground(new Color(165,82,0)); // setting the background colour of the main panel to a brown colour.
        main.setLayout(new GridLayout(11, 2, 0, 15)); // setting the layout of the main panel using Gridlayout.
        JPanel key = new JPanel(); // creating a new panel key to store the hidden combination from machine / user.
        key.setBackground(new Color(165,82,0)); // setting the background ok key to the same colour as the main panel.
        key.setLayout(new FlowLayout()); // new flow layout used to keep it centre aligned.

        // creating buttons to store kb , and adding to the key panel
        kb = new input[4]; // allow computer to have an input of 4 buttons on each guess.
        for (int i=0; i<4; i++) { // loop through combination of preset combination.
            kb[i] = new input(); // add a new button until i hits the combination limit , in this case 4 pegs.
            key.add(kb[i]);// add the input buttons to the key panel.
        }

        // break between hidden combination and computer guesses
        main.add(new JSeparator(SwingConstants.HORIZONTAL)); // adding a separator in between the kb and the guess elements within gui.
        main.add(new JSeparator(SwingConstants.HORIZONTAL));// adding a separator in between the kb and the guess elements within gui.

        //create guess panels and corresponding clue panels
        JPanel guessPan[] = new JPanel[10];// creating the guess panel with a value of 10 to allow computer to guess upto 10 times. 
        JPanel bwPan[] = new JPanel[10]; // creating 10 panel allowing 10 sets of black and white pegs within gui.
        com_guess = new input[10][4]; // allowing computer to guess 4 combinations in length and total of 10 guesses.
        bwPegs = new output[10][4]; // creating the black and white pegs for total number of guesses (10) and 4 pegs for each guess.
        for (int i=0; i<10; i++) { // for every guess (10 guesses) do the following.
            bwPan[i] = new JPanel(); // create a panel to store the black and white pegs.
            bwPan[i].setBackground(new Color(165,82,0)); // set the background the of the panel to brown.
            bwPan[i].setLayout(new GridLayout(1,4));// set grid layout to 1 by 4 (in a row). 
            guessPan[i] = new JPanel(); // create another panel for black and white pegs.
            guessPan[i].setBackground(new Color(127,64,1));// setting background of computer guess panel to a dark brown colour.
            for (int j=0; j<4; j++){ // for every button/peg guess do the following.
                bwPegs[i][j] = new output(); // display new black/white pegs.
                bwPan[i].add(bwPegs[i][j]); // add new black and white pegs to the panel.
                com_guess[i][j] = new input(); // display and give the computer the guessing (peg) buttons.
                guessPan[i].add(com_guess[i][j]); // add the guessing buttons to the computer's guess panel.
            }
            main.add(bwPan[i]); // add  the black and white pegs to the panel.
            main.add(guessPan[i]); // add black and white pegs to the panel.
        }

        // enter button
        Enter = new JButton("Enter combination"); // button used to also allow the player to play if wanted.
        JPanel enter = new JPanel(); // creating panel for enter button.
        enter.setBackground(new Color(0,169,230)); // setting background colour of enter button.
        enter.add(Enter); // adding enter button to the enter panel.

        // main container pane.
        Container win = this.getContentPane(); // initialising new container to store panels.
        win.setLayout(new BorderLayout()); // initialising new layout.
        win.add(key, BorderLayout.NORTH); // add the key panel to the north of container
        win.add(main, BorderLayout.CENTER);// add the main panel to centre of panel.
        win.add(enter, BorderLayout.SOUTH);// add the enter panel to the south of the container pane.

        // 
        this.setDefaultCloseOperation(Advanced_Strategy.EXIT_ON_CLOSE); // exit on window close.
        this.setSize(400, 700); // set size of the window
        this.setVisible(true);// make visible to user.
    }

    public void initVals() { // initialise values on start and restart
        //ask for and set game mode
    	
        Object[] option = {"Player", "Machine"}; // give user option of either playing or machine playing.
        type = JOptionPane.showOptionDialog(null,"Select a playing option","Select a Game Mode", // prompt.
                                            JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,null, // yes and no options.
                                            option,option[0]);// option buttons
        count = 9;// put the guess count to 9.
        for (int i=0;i<4;i++) { // for every 4 choices / pegs do following
            if (type == 0) { // if the user selects yes from above , then enter player option.
                kb[i].setViz(false); // set the guess code to false.
                kb[i].setColour((ran.nextInt(6) + 1)); // randomise the colour combination for user to guess.
            } else { // set to machine play.
                kb[i].setColour(0);// current colour 
                kb[i].setEdit(true);// allow the user to select own combination for machine to guess.
            }
        }
        if (type == 0) {// if the user selects player mode then do the following.
            kbValue = stringVal(kb); // take the value of the random combination and assign it to the hidden combination if in player option.
        }// end if.
        for (int i=0; i<10; i++) { // loop through for every guess computer makes.
            for (int j=0; j<4; j++) { // loop through computer guess combination
                com_guess[i][j].setColour(0); // set current colour/ peg combination made by the computer
                if (i==9 && type == 0) { // if number of guesses is 9 (10 in total) then do the following
                    com_guess[i][j].setEdit(true); // show combination (see input class).
                } else {// else
                    com_guess[i][j].setEdit(false); // do not allow user to see combination (see input class).
                }
                bwPegs[i][j].setColour(0); // set the black/white pegs to default colour (see output class).
            }
        }
    }
    // get string value of a set of input buttons
    // this is helpful to have for scoring
    public String stringVal(input[] buttons) { // storing the value of the coloured peg buttons as a string , to allow user to loop through coloured peg selection.
        String val = new String(); // initialising new string object val to store value of colours as a string.

        for (int i=0; i<buttons.length; i++) {// 
            val += String.format("%d", buttons[i].getColour());// get the current colour what the user/machine is on and assign it to val as a string.
        }// end for

        System.out.println(val); // print out current value of button to console for testing purposes.
        return val;// return the string val.
    }

    // register listener for enter button
    public void Listeners() {// listeners function to handle event listener.
        Enter.addActionListener(this); // add an action listener to the enter button.
    }

    // setting action for enter button
    public void actionPerformed(ActionEvent e) {// function to handle the actions performed within window.
        System.out.println(e.getActionCommand()); // print out the command made by user/machine to console for testing purposes.
        if (e.getSource() == Enter && type == 0) { // if the user has pressed enter and the type (game type) is 0 do the following
            // player mode
            submit();// call submit function to allow user to submit guess.
        } else if (e.getSource() == Enter && type == 1) { // else if enter has been pressed and  the user selects 2nd (option[1]) then do the following
            // machine mode
            playMachine(); // call the playMachine function , enabling machine to guess.
        } else {//else
            System.out.println("ACTION EVENT ERROR!"); // print out error if the above fails.
        }
    }
    
    public void submit() {// checks to see if the guess made by player or machine is correct.
        
        if (valid(com_guess[count])) { // check to see if the input/guess is valid.
            //success = returnBW(); // set the boolean success to return a black or white peg(s) (see output.class).
            //if(com_guess[count][1] == kb[1]){
            	//bwPegs[1][0] = 
            //}

            
            count--; // decrement guess counter for the next guess

            // check if out of guesses, player loses
            if (count < 0) { // if the user/machine has more than 10 guesses then do the following
                fail(false); // set fail to false.
                return; // return.
            }

            
            for (int i=0; i<4; i++) { // loop through the current peg combination.
                com_guess[count][i].setEdit(true); // enable next guess.
                com_guess[count+1][i].setEdit(false); // diable previous guess.
            }
        }
    }
    
    public boolean valid(input[] button) { // valid function used to check to see if the input by user/machine is valid.
        for (int i=0; i<4; i++) { // loop through the combination of the input
            if (button[i].getColour() == 0) {// get the current colour that the user / machine is on , if it's value is 0 
                return false; // then return false.
            }
        }
        return true; // return true if the input/guess is valid.
    }
    public void fail(boolean win) { // fail function used to check if the player / machine has exceeded guesses , basically lost.
        // reveal the key
        for (int i=0; i<4; i++) { // loop through the 4 peg hidden combination.
            kb[i].setViz(true); // set the hidden combination visibility to true , enabling user to see it.
        }
    
    String prompt = new String(); // string object to be used to store the prompt (output message to user).
    if (win) {// if win is true do following
        prompt = "Game won!"; // prompt user game is won.
    } else {// else.
        prompt = "Game lost!"; // prompt user , game is lost.
    }

    // display message and ask for new game
    int ans = JOptionPane.showConfirmDialog(null,"Do you want to play again?",prompt, JOptionPane.YES_NO_OPTION, // show prompt in dialog box with yes/no options.
                                      JOptionPane.PLAIN_MESSAGE);// plain pane message format.

    // reset game, or end
    if (ans == 0) {// if option is yes then do the following
        initVals(); // re-initialise the values of the game , reset the game over again.
    } else if (ans == 1) {//else if the option is no do the following.
        System.exit(0); // exit/close window.
    } else {// else
        System.out.println("ERROR!"); // print error message to console for testing purposes.
    }
}
    public void playMachine() { // using naive strategy used within pdf (see pdf for more info).
        	if(moves >=1){// if number of moves is greater or equal to 1 , do
        		moves = 1; // reset moves back to 1 everytime , function is called.
        	}
        	if (valid(kb)) {// make sure user has entered a valid key
            // holds computer guess and score of guess
             // save string version of user-provided key
            kbValue = stringVal(kb);// storing kbValue as the string value of kb
            int randChoice = ran.nextInt((6 - 1) + 1) + 1; // set random choice (ran.nextInt(max - min + 1) + min).
            // computer's initial guess
            // display guess, check for a win and display clue
            // calculate guess score
        	do{// do following
        	switch(moves){ // switch case using moves as an argument
        	case 1:  // if moves is 1(case 1)
	            com_guess[count][0].setColour(1); // set the first button colour to 1 , red.
	            com_guess[count][1].setColour(1); // set the second button colour to 1 , red.
	            com_guess[count][2].setColour(2); // set the third button colour to 2 , blue.
	            com_guess[count][3].setColour(2); // set the fourth button colour to 2 , blue.
	            submit(); // submit combination
	            moves+= 1; // increment moves
            break; // break case.
        	case 2: // if moves is 2 (case 2)
                com_guess[count][0].setColour(1); // set the first button colour to 1 , red.
                com_guess[count][1].setColour(1); // set the second button colour to 1 , red.
                com_guess[count][2].setColour(3); // set the third button colour to 3 , blue.
                com_guess[count][3].setColour(3); // set the fourth button colour to 3 , blue.
                submit();// enter combination
                moves+= 1; // increment moves
                break;// break case.
        	case 3:  // if moves is 3 (case 3)
                com_guess[count][0].setColour(4); // set the first button colour to 4 , red.
                com_guess[count][1].setColour(4); // set the second button colour to 4 , red.
                com_guess[count][2].setColour(3); // set the third button colour to 3 , blue.
                com_guess[count][3].setColour(3); // set the fourth button colour to 3 , blue.
                submit(); // enter combination
                moves+= 1;// increment moves
                break;// break case.
               
        	case 4:case 5:case 6: case 7: case 8: case 9: case 10: // if moves is 4 to 10 (case 4 to 10)
        		 while(moves<=10){ // while total moves is less than 10 do
                com_guess[count][0].setColour(1); // set the first button colour to 1 , red.
                com_guess[count][1].setColour(3); // set the second button colour to 1 , red.
                com_guess[count][2].setColour(4); // set the third button colour to 2 , blue.
                com_guess[count][3].setColour(randChoice); // set the fourth button colour to 2 , blue.
                randChoice +=1; // increment random choice 
                if(randChoice > 6){ // if random choice exceeds 6 then do following
                	randChoice = ran.nextInt((6 - 1) + 1) + 1; // resets random choice to ensure index 3 is not always same random choice.
                }// end if
                submit(); // call submit function.
                moves+= 1; // increment moves.
        		 }// end while loop
                break; // break case.
        	}// end switch case.
        	}while(moves <=10); // do while moves is less than or equal to 10.
}
}
}

/*REFERENCES:

Java Labs
Java Lectures

I had used an online reference as a guide to refer to swing components - https://docs.oracle.com/javase/7/docs/api/javax/swing/package-summary.html

Please refer to pdf provided Naive_Strategy.pdf which explains my research of the strategy used.

*/