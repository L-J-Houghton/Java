package question_2;// package name
import java.awt.*; // importing awt package.
import javax.swing.*; // importing swing package.
import java.awt.event.*; // importing awt event package to handle event action/listener.


// Custom button to take input for both Advanced strategy and Naive strategy games.
public class input extends JComponent implements MouseListener { // class input inherits JComponent and implements mouse listener interface.
    // properties of button
    private int  curColour; // current colour of the button being stored as an int.
    private Color colours[]; // an array of colours to store the colours.
    private boolean mousePressed; // boolean mousepressed to check if the user has pressed mouse , if so then set to true else false.
    private boolean editable; // boolean enabling the button to be edited, if false user/machine cannot edit buttons.
    private boolean visible; // boolean allowing the element to be visible to the user within the gui.
    // constructor - initialize values
    public input() { // input constructor
        this.addMouseListener(this); // add mouse listener event using this attribute.

        curColour = 0; // initially set the colour to 0 (red).
        mousePressed = false; // set mouse pressed to false by default.
        editable = false; // set editable to false by default.
        visible = true; // set visibility to true , by default.
        colours = new Color[7]; // initialise array colours with total of 7 colours for coloured pegs.
        colours[0] = Color.BLACK; // set index 0 of colours to black.
        colours[1] = Color.RED; // set index 1 of colours to red.
        colours[2] = Color.BLUE; // set index 2 of colours to blue.
        colours[3] = Color.GREEN; // set index 3 of colours to gree.
        colours[4] = Color.YELLOW; // set index 4 of colours to yellow.
        colours[5] = Color.ORANGE; // set index 5 of colours to orange.
        colours[6] = Color.MAGENTA; // set index 6 of colours to magneta.
    }// end constructor.

    // redraw button function.
    public void paint(Graphics i) { // 
        // if mouse was clicked, go to next color
    	Graphics2D g = (Graphics2D)i;
        if (mousePressed) {// if mosued pressed is true do the following
            if (curColour == 6) { // if the colour hits the end of the array
                curColour = 1; // reset the colour back to red (1).
            } else { // else
                curColour++; // keep incrementing, running through array.
            }
        }
        // if visible, show color change
        if (visible) { // visible is true then do
            g.setColor(colours[curColour]); // show the colour change.
        }
        // then redraw
        if (curColour == 0 || !visible) {// if the current colour is black or not visible to the user then 
        	g.drawRoundRect(0, 0, 30, 30, 10, 10); // draw a round rectangle 30 height , 30 width.
        } else {// else
            g.fillOval(0,0,30,30); // fill empty hole with coloured peg.
        }
    }

    // get current colour
    public int getColour() { // integer value to get the current colour user/machine is on.
        return curColour; // return the current colour user/machine is on.
    }

    //set color and then redraw
    public void setColour(int newColor) { // set the colour.
        curColour = newColor; // set the current colour.
        repaint();// redraw/repaint.
    }

    //set edit state
    public void setEdit(boolean edit) { // function to set boolean edit to true/false when needed.
        editable = edit; // set edit.
    }

    // set visible state and redraw
    public void setViz(boolean vis) { // setViz used to control visible boolean.
        visible = vis;// setting visible
        repaint(); // redraw / repaint.
    }

    // set default size of component
    public Dimension getMinimumSize() { // get the minimum size of the pegs.
        return new Dimension(30,30); // return dimensions of the pegs size for proportion purposes.
    }
    public Dimension getPreferredSize() { // get the preferred size of the pegs.
        return new Dimension(30,30); // return dimensions of the preferred size for proportion purposes.
    }

    // if mouse pressed and editable, then redraw
    public void mousePressed(MouseEvent e) {
        if (editable) { // if editable is true.
            mousePressed = true; // and mouse has been pressed.
            repaint(); // redraw / repaint.
        }
    }
    public void mouseReleased(MouseEvent e) { // keep track of mouse being released.
        mousePressed = false; // if mouse is not released set to false.
    }

    // required when implementing mouselistener
    public void mouseClicked(MouseEvent e) {} // function to handle mouse click event 
    public void mouseEntered(MouseEvent e) {}// function to handle mouse enter event 
    public void mouseExited(MouseEvent e) {} // function to handle mouse exit event 
}