package question_2;// package name.

import java.awt.*; // import awt package.
import javax.swing.*; // import swing package.
import java.awt.event.*;// import awt package to handle events.

// custom button to display clues for Mastermind
public class output extends JComponent {// output class inherits JComponent class (see import).
    private int  curColour; // current colour variable.

    // constructor
    public output() { //output  constructor used for outputting pegs.
        curColour = 0; // initially set to 0 , this will just draw an outline of a circle (see below)
    }// end constructor.

   
    public void paint(Graphics g) {  //paint function used to draw and colour black/white pegs.
        if (curColour == 1) { // if the currrent colour happens to be 1 (white peg) then 
            g.setColor(Color.WHITE); // set the colour of that peg to white
            g.fillOval(0,0,10,10); // fill the circle (peg) with white colour.
        } else if (curColour == 2) { // else if the current colour is 2.
            g.setColor(Color.BLACK); // set the current colour to black (black pegs)
            g.fillOval(10,10,10,10);// fill the peg black to indicate a black peg.
        } else { // else
            g.setColor(Color.BLACK); // set the current colour balck
            g.drawOval(0,0,10,10); // draw outline of a circle , where peg should be.
            
        }
    }

    
    public int getColour() { // get colour as an int
        return curColour; // return the current colour.
    }
    public void setColour(int newColour) { // set the current colour function
        curColour = newColour;// assign / set the current colour
        repaint(); // redraw / repaint
    }

    
    public Dimension getMinimumSize() { // minimum size Dimension returns the default component (peg size).
        return new Dimension(50,50); //set default size.
    }
    public Dimension getPreferredSize() { // preferred size Dimension returns the default component (peg size).
        return new Dimension(50,50);  //set default size.
    }
}