package question_1;// package name.

import java.io.*; // import import/output library.
import java.sql.*; // import sql library.
import java.util.*; // import all utility libraries.
public class outputData{// class to output data from database.
    public static void main(String[] args) { // main mehtod.
            List data = new ArrayList(); // creating a list 
            try {// try following
                    Connection con = null;// set the connection to null initially.
                    Class.forName("com.mysql.jdbc.Driver"); // get the driver from the jdbc jar file.
                    con = DriverManager.getConnection("jdbc:mysql://localhost:3306/students", "root", "");// set destination link.
                    Statement st = con.createStatement();// initialising statement to be used via the connection made above.
                    ResultSet rs = st.executeQuery("Select * from marks_table"); // results set used to store informtion selected from table in database.

                    String format = "%4s  %-12s   %-12s   %-21s%n"; // formatting purposes to make output presentable.
                    data.add(String.format(format, "ID", "NAME", "YEAR", "MARKS")); // column headers.
                    while (rs.next()) { // while the result set has values do the following.
                            int id = rs.getInt("id"); // get the int id from the id field in table.
                            String name = rs.getString("name");// get the string name from name field in table.
                            int year  = rs.getInt("year");// get the int year from the year field in table.
                            int marks = rs.getInt("marks");// get the int marks from the marks field in table.
                            data.add(String.format(format, id+" ", name+"", year, marks)); // format the results found and add them to the list.

                    }
                    writeToFile(data,"output-marks.txt"); // write to the file the list storing values from database.
                    rs.close(); // close result set.
                    st.close(); // close statement.
            } catch (Exception e) {// catch exception if the above throws errors.
                    System.out.println(e); // print exception errors in detail.
            }
    }

    private static void writeToFile(@SuppressWarnings("rawtypes") java.util.List list, String path) { // write to file method used to write the list to the file.
            BufferedWriter out = null; // initially set reader to null.
            try { // try the following
                    File file = new File(path);
                    out = new BufferedWriter(new FileWriter(file, true)); // initialise new buffered writer and file writer to enable the program to wrote to selected filepath , set to true to enable this.
                    for (Object s : list) { // for all objects within the list do the following.
                            out.write((String)s); // write to the file each value as a string.
                            out.newLine(); // print each object within the list on a new line.

                    }
                    out.close(); // close buffered reader on finish.
                    System.out.println("Completed!"); // alert message in console to signify completion.
            } catch (IOException e) {// catch exception error if the above try block throws errors.
            }
    }
}