package question_1;// package name

import java.io.BufferedReader; // import buffered reader.
import java.io.FileInputStream; // import file input stream library.
import java.io.IOException; // import exceptions library.
import java.io.InputStreamReader; // import input stream reader library.
import java.sql.Connection; // import jdbc for connections library.
import java.sql.DriverManager; // import jdbc (driver manager) library.
import java.sql.PreparedStatement; // import jdbc (prepare statement) used for preparing sql statements.
import java.sql.ResultSet; // import results set to store results library.
import java.util.ArrayList; // import arraylists to store data.



public class insertData{ // insert data class.
		
	public static void main(String args[]) { // main class.
		
			try{ // try block..
				
				ResultSet result; // creating result set to store results of data pulled from the database. 

				Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/students","root",""); // db connection using local host and database given in sql provided.
				
				String query = "insert into marks_table values(?, ?, ?, ?)"; // insertion query used to insert values into table  see below.


				java.sql.Statement stmentt = connect.createStatement(); // creating statement using db connection. // creating a statement by connecting to the database using the connection established above.
				
				PreparedStatement insert_data = connect.prepareStatement(query); // prepare the statement and process the query through the connection made (see above 'connect').
				
				ArrayList<getSet> marksList = getListjdbcFromTextFile("input-marks.txt"); // using an arraylist to store the data collected from the input file via the file reader.
				
				for(int i= 0; i<marksList.size(); i++){ // for loop to loop through the above arraylist marksList ..
					
					insert_data.setInt(1, marksList.get(i).getId()); // set/get values at postion 1 on every cycle to the id of the student.
					insert_data.setString(2, marksList.get(i).getName()); // set/get values at postion 2 of the array on every cycle to the name of the student.
					insert_data.setInt(3, marksList.get(i).getYos()); // set/get values at postion 3 of the array on every cycle to the year of the student.
					insert_data.setString(4, marksList.get(i).getMarks()); // set/get values at postion 4 of the array on every cycle to the marks of the student.
					
					insert_data.executeUpdate(); // execute the statement used above , to 
					System.out.println("Successfully inserted id number:"+(i+1)); // print out the current status of inserted records.
				}
				
				}catch(Exception e){} // catch exception used if the try block returns any errors.
			 System.out.println("End"); // end used to signify all records have been inserted.
	}
	
	
			public static ArrayList<getSet> getListjdbcFromTextFile(String filepath){ // arraylist used to get the values from getset class which is used to take values from the input file.
				
				FileInputStream fis = null; // set file input stream to null to begin with.
				InputStreamReader isr = null; // set input stream reader to null to begin with.
				BufferedReader bfr = null; // set buffered reader to null to begin with.
				ArrayList<getSet> marksResult = new ArrayList<getSet>(); // creating an new arraylist to store each record (this will be used to store values from each record of the input file).
				
				try{ // try block used to do the following.
					fis = new FileInputStream(filepath); // initialise the file input stream.
					isr = new InputStreamReader(fis); // initialise input stream reader.
					bfr = new BufferedReader(isr);// initialise buffered reader.
					
					String line = null; // set the string variable line to null to begin as no data is collected yet.
					
					String[] marks = null; // set the marks array to null as no values will exist in array to begin with.
					
					
					while(true){ // while the following is true 
						line = bfr.readLine(); // using buffered reader to read each line of the file as a string.
						
						if(line == null){ // if the line variable hits an end within the file (null) then break the loop and stop reading.
							break; // break loop.
						}else{
							marks = line.split(","); // ignore commas which seperate fields in input file.
							marksResult.add(new getSet(Integer.parseInt(marks[0]), marks[1], Integer.parseInt(marks[2]), marks[3])); // add a new getSet (arraylist) with the values collected from the input file , parsing int values where necessary.
						
							
						}
						
					}
					
				}catch(Exception e){
					System.out.println("Cannot read file!, try again"); // error message displays if the above try block fails (fails to read file).
					e.printStackTrace();// print stack trace for debugging purposes.
				}finally{ // finally do
					try{ // try following
					bfr.close(); // close buffered reader.
					isr.close();// close input stream reader.
					fis.close();// close file input stream
					}catch(IOException e){ // catch exception used if the above caanot close.
						e.printStackTrace(); // print detailed error message (stackTrace).
					}// end catch
				}
				return marksResult; // return the results which shall be inserted into database.
			}
	}

	
