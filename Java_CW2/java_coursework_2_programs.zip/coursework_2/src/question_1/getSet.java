package question_1;// package name.

 
public class getSet{ // class used to get values from input file and set values from input file.
 
	private int id; // int id used to store id.
	private String name; // string name used to store name of student.
	private int yos; // int yos used to store year of student.
	private String marks;// stirng marks used to store grade of student.
	public int getId() { // get the id of student.
		return id; // return of student.
	}
	public void setId(int id) { // set id of student using id assigned.
		this.id = id; // assign the id found within file.
	}
	public String getName() { // get name of student.
		return name; // return name of student.
	}
	public void setName(String name) { // using the name returned , then set the name of student.
		this.name = name; //, then set the name of student.
	}
	public int getYos() { // get year of student's study
		return yos; // return year of study.
	}
	public void setYos(int yos) { // using the return parse it through the setter.
		this.yos = yos; // assign value found.
	}
	public String getMarks() { // get marks of student.
		return marks; // return mark of student.
	}
	public void setMarks(String marks) { // set mark using returned value.
		this.marks = marks; // assign marks.
	}
	public getSet(int id, String name, int yos, String marks2) {  // making superclass constructor which will be used within the other jdbc programs.
		super(); // calling super (parent) class.
		this.id = id;  // using this attribute to assign the values (id) from the get/set methods.
		this.name = name; // using this attribute to assign the values (name) from the get/set methods.
		this.yos = yos; // using this attribute to assign the values (year) from the get/set methods.
		this.marks = marks2;// using this attribute to assign the values (marks) from the get/set methods.
	}
	
	
	
}